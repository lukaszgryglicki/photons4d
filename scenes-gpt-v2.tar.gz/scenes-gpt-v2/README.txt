These are second-pass GPT-retuned scene JSON variants derived from the earlier *-gpt set.

What changed in this pass:
- reviewed a much larger batch of original GIF/MP4 outputs
- identified scenes that were still too dim, too sphere-like, or too dominated by direct-light washout
- selectively increased SPP / probe rays / maxBounces
- raised gamma (tone curve) for dark scenes
- tightened key lights and strengthened side/fill lights where structure was being lost
- for a few scenes, slightly enlarged or repositioned the main object to improve slice visibility
- big_mixed_scene-gpt received a central refractive lens anchor to make its middle slices more informative

Only scenes that still looked weak were changed materially; the stronger ones were left alone.
See MANIFEST.json for the per-file summary.
